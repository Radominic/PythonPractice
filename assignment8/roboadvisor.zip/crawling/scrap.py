# -*- coding: utf-8 -*-
"""
Created on Sun May 10 16:48:22 2020

@author: Gangmin
"""


def scrap_test():
    print("scrap")