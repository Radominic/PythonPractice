# -*- coding: utf-8 -*-
"""
Created on Sun May 10 16:48:14 2020

@author: Gangmin
"""

def series_test():
    print("series")